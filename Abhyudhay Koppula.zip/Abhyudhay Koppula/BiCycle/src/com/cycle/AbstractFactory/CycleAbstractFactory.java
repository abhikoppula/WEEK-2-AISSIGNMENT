package com.cycle.AbstractFactory;

import com.cycle.beans.Cycle;

public interface CycleAbstractFactory {
	
	public Cycle createCycle();

}
