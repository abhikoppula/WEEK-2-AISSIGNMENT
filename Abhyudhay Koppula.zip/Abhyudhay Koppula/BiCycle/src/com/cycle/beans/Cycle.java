package com.cycle.beans;

public interface Cycle {
	
	public String getBells();
	public String getBatteryAssistedPower();
	public int getGear();
	

}
